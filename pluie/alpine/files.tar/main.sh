#!/bin/bash
# @app      pluie/alpine
# @author   a-Sansara https://git.pluie.org/pluie/docker-images

. /scripts/common.sh
bash
